import "./style.css";
import banner from "../../imgs/Illustration-of-an-exit-rate 1.png";

function Banner() {
  return (
    // <div className="Banner">
    //   <div className="study1">
    //     <div className="study"> </div>
    //   </div>
    // </div>
    <div className="Banner">
      <img src={banner} alt="" />
    </div>
  );
}

export default Banner;